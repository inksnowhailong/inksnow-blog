import{l as i}from"./element-plus-380619eb.js";import{_ as p}from"./index-78f45112.js";import{a6 as l,o as e,c as r,a as t,G as u,z as d,A as o,I as s,a7 as a}from"./@vue-4ea5409b.js";import"./@vueuse-f2670ca4.js";import"./@element-plus-0dd7aa74.js";import"./@ctrl-eb0b847c.js";import"./lodash-es-36d0cce0.js";import"./@popperjs-892fd7f5.js";import"./vue-router-312e0124.js";import"./vuex-6254f35d.js";import"./prismjs-746e6908.js";import"./dayjs-47b942cd.js";import"./lodash-ce277f77.js";const m={},_=t("h1",null,"TypeScript\u7684\u914D\u7F6E\u6587\u4EF6tsconfig.json\u914D\u7F6E\u89E3\u6790",-1),h=t("p",null," TypeScript\u53EF\u4EE5\u7F16\u8BD1\u51FA\u7EAF\u51C0\u3001 \u7B80\u6D01\u7684JavaScript\u4EE3\u7801\uFF0C\u5E76\u4E14\u53EF\u4EE5\u8FD0\u884C\u5728\u4EFB\u4F55\u6D4F\u89C8\u5668\u4E0A\u3001Node.js\u73AF\u5883\u4E2D\u548C\u4EFB\u4F55\u652F\u6301ECMAScript3\uFF08\u6216\u66F4\u9AD8\u7248\u672C\uFF09\u7684JavaScript\u5F15\u64CE\u4E2D\u3002 ",-1),S=t("p",null," \u7C7B\u578B\u5141\u8BB8JavaScript\u5F00\u53D1\u8005\u5728\u5F00\u53D1JavaScript\u5E94\u7528\u7A0B\u5E8F\u65F6\u4F7F\u7528\u9AD8\u6548\u7684\u5F00\u53D1\u5DE5\u5177\u548C\u5E38\u7528\u64CD\u4F5C\u6BD4\u5982\u9759\u6001\u68C0\u67E5\u548C\u4EE3\u7801\u91CD\u6784\u3002 \u7C7B\u578B\u662F\u53EF\u9009\u7684\uFF0C\u7C7B\u578B\u63A8\u65AD\u8BA9\u4E00\u4E9B\u7C7B\u578B\u7684\u6CE8\u91CA\u4F7F\u4F60\u7684\u4EE3\u7801\u7684\u9759\u6001\u9A8C\u8BC1\u6709\u5F88\u5927\u7684\u4E0D\u540C\u3002\u7C7B\u578B\u8BA9\u4F60\u5B9A\u4E49\u8F6F\u4EF6\u7EC4\u4EF6\u4E4B\u95F4\u7684\u63A5\u53E3\u548C\u6D1E\u5BDF\u73B0\u6709JavaScript\u5E93\u7684\u884C\u4E3A\u3002 ",-1),f=t("h2",null,"1.experimentalDecorators",-1),y=t("span",{class:"parse"},"\u662F\u5426\u542F\u7528\u5B9E\u9A8C\u6027\u7684ES\u88C5\u9970\u5668\u3002",-1),E=s(" boolean\u7C7B\u578B\uFF0C\u9ED8\u8BA4\u503C\uFF1Afalse\u3002 "),b=s("\u5B98\u65B9\u89E3\u91CA"),g=t("br",null,null,-1),q=s(" \u5F88\u591A\u5E93\u90FD\u6709\u7528\u5230\u8BE5\u7279\u6027\uFF0C\u6BD4\u5982vue-class-component \u53CA vuex-class\u7B49\u5E93\u3002"),x=t("strong",null,"\u5F53\u4F60\u4F7F\u7528\u8FD9\u4E9B\u5E93\u65F6\uFF0C\u5FC5\u987B\u5F00\u542FexperimentalDecorators\u3002",-1),v=a('<span class="cite">\u542F\u7528 vuex-class\u540C\u65F6\u9700\u8981\u8BBE\u7F6EstrictFunctionTypes\u9009\u9879\u4E3Afalse</span><h2>2. strictPropertyInitialization</h2><p><span class="parse"> \u662F\u5426\u7C7B\u7684\u975Eundefined\u5C5E\u6027\u5DF2\u7ECF\u5728\u6784\u9020\u51FD\u6570\u91CC\u521D\u59CB\u5316\u3002</span> boolean\u7C7B\u578B\uFF0C\u9ED8\u8BA4\u503C\uFF1Afalse <br> \u76F4\u767D\u70B9\uFF0C\u5C31\u662F\u6240\u6709\u7684\u5C5E\u6027\u503C\uFF0C\u90FD\u9700\u8981\u8D4B\u6709\u521D\u59CB\u503C\u3002<strong>\u5EFA\u8BAE\u628AstrictPropertyInitialization\u8BBE\u7F6E\u4E3Afalse</strong>\uFF0C \u8FD9\u6837\u5C31\u4E0D\u9700\u8981\u5B9A\u4E49\u4E00\u4E2A\u53D8\u91CF\u5C31\u5FC5\u987B\u8D4B\u6709\u521D\u59CB\u503C\u3002\u5BF9\u4F7F\u7528vuex-class\u5E93\u7684\u670B\u53CB\uFF0C\u5EFA\u8BAE\u8BF7\u628A\u8FD9\u4E2A\u503C\u8BBE\u4E3Afalse\uFF0C\u7EDD\u5BF9\u80FD\u7701\u5F88\u591A\u4E8B\u3002 </p><span class="cite">\u5982\u679C\u8BBE\u7F6E\u8BE5\u9009\u9879\u4E3Atrue\uFF0C\u9700\u8981\u540C\u65F6\u542F\u7528--strictNullChecks\u6216\u542F\u7528--strict</span><h2>3. noImplicitAny</h2><p><span class="parse">\u6709\u9690\u542B\u7684 any\u7C7B\u578B\u65F6\u662F\u5426\u62A5\u9519\u3002</span> boolean\u503C\uFF0C\u9ED8\u8BA4\u503C\uFF1Afalse <br> ts\u662F\u6709\u9ED8\u8BA4\u63A8\u5BFC\u7684\uFF0C\u540C\u65F6\u8FD8\u6709any\u7C7B\u578B\uFF0C\u6240\u4EE5\u4E0D\u662F\u6BCF\u4E2A\u53D8\u91CF\u6216\u53C2\u6570\u5B9A\u4E49\u9700\u8981\u660E\u786E\u544A\u77E5\u7C7B\u578B\u662F\u4EC0\u4E48\u3002 \u5982\u679C\u5F00\u542F\u8BE5\u503C\uFF0C\u5F53\u6709\u9690\u542Bany\u7C7B\u578B\u65F6\uFF0C\u4F1A\u62A5\u9519\u3002\u5EFA\u8BAE\u521D\u6B21\u4E0A\u624BTypeScript\uFF0C\u628A\u8BE5\u9009\u9879\u8BBE\u7F6E\u4E3Afalse\u3002 </p>',6),k={class:"line-numbers"},j=s("        "),N={class:"language-javascript"},D=s(`\r
       // \u5F53\u5F00\u542FnoImplicitAny\u65F6\uFF0C\u9700\u8981\u9690\u542B\u5F53any\u9700\u8981\u660E\u786E\u6307\u51FA\r
        arr.find(item => item.name === name) // error  \u53C2\u6570\u201Citem\u201D\u9690\u5F0F\u5177\u6709\u201Cany\u201D\u7C7B\u578B\u3002ts(7006)\r
        arr.find((item: any) => item.name === name) // ok   \r
        `),M=[D],T=a('<h2>4. target</h2><p><span class="parse">\u6307\u5B9A\u7F16\u8BD1\u7684ECMAScript\u76EE\u6807\u7248\u672C\u3002</span> \u679A\u4E3E\u503C\uFF1A&quot;ES3&quot;\uFF0C &quot;ES5&quot;\uFF0C &quot;ES6&quot;/ &quot;ES2015&quot;\uFF0C &quot;ES2016&quot;\uFF0C &quot;ES2017&quot;\uFF0C&quot;ESNext&quot;\u3002\u9ED8\u8BA4\u503C\uFF1A \u201CES3\u201D <br> TypeScript\u662FES6\u7684\u8D85\u96C6\uFF0C\u6240\u4EE5\u4F60\u53EF\u4EE5\u4F7F\u7528ES6\u6765\u7F16\u5199ts\u4EE3\u7801\uFF08\u901A\u5E38\u6211\u4EEC\u4E5F\u7684\u786E\u8FD9\u4E48\u505A\uFF09\u3002 <br> \u7136\u800C\uFF0C\u5F53\u7F16\u8BD1ts\u4EE3\u7801\u65F6\uFF0C\u53EF\u4EE5\u628Ats\u8F6C\u4E3AES5\u6216\u66F4\u65E9\u7684js\u4EE3\u7801\u3002\u6240\u4EE5\u9700\u8981\u9009\u62E9\u4E00\u4E2A\u7F16\u8BD1\u7684\u76EE\u6807\u7248\u672C\u3002 vue-cli3\u7684typescript\u6A21\u677F\uFF0C\u8BBE\u7F6E\u4E3A\u201CESNext\u201D\uFF0C\u56E0\u4E3A\u73B0\u4EE3\u5927\u90E8\u5206\u5E94\u7528\u9879\u76EE\u90FD\u4F1A\u4F7F\u7528Webpack\uFF08Parcel\u4E5F\u5F88\u68D2\uFF09\u8FDB\u884C\u6253\u5305\uFF0C Webpack\u4F1A\u628A\u4F60\u7684\u4EE3\u7801\u8F6C\u6362\u6210\u5728\u6240\u6709\u6D4F\u89C8\u5668\u4E2D\u53EF\u8FD0\u884C\u7684\u4EE3\u7801\u3002 </p><span class="cite">target: &quot;ESNext&quot; \u662F\u6307tc39\u6700\u65B0\u7684ES proposed features</span><h2>5. module</h2><p><span class="parse">\u6307\u5B9A\u751F\u6210\u54EA\u4E2A\u6A21\u5757\u7CFB\u7EDF\u4EE3\u7801\u3002</span> \u679A\u4E3E\u503C\uFF1A&quot;None&quot;\uFF0C &quot;CommonJS&quot;\uFF0C &quot;AMD&quot;\uFF0C &quot;System&quot;\uFF0C &quot;UMD&quot;\uFF0C &quot;ES6&quot;\uFF0C &quot;ES2015&quot;\uFF0C&quot;ESNext&quot;\u3002 \u9ED8\u8BA4\u503C\u6839\u636E--target\u9009\u9879\u4E0D\u540C\u800C\u4E0D\u540C\uFF0C\u5F53target\u8BBE\u7F6E\u4E3AES6\u65F6\uFF0C\u9ED8\u8BA4module\u4E3A\u201CES6\u201D\uFF0C\u5426\u5219\u4E3A\u201Ccommonjs\u201D <br><p> \u901A\u5E38\u4F7F\u7528ES6\u7684\u6A21\u5757\u6765\u5199ts\u4EE3\u7801\uFF0C\u7136\u800C2016\u5E741\u6708\u4EE5\u524D\uFF0C\u57FA\u672C\u4E0A\u6CA1\u6709\u6D4F\u89C8\u5668\u539F\u751F\u652F\u6301ES6\u7684\u6A21\u5757\u7CFB\u7EDF\uFF0C\u6240\u4EE5\u9700\u8981\u8F6C\u6362\u4E3A\u4E0D\u540C\u7684\u6A21\u5757\u7CFB\u7EDF\uFF0C\u5982\uFF1ACommonJS\u3001AMD\u3001SystemJS\u7B49\uFF0C\u800Cmodule\u9009\u9879\u5C31\u662F\u6307\u5B9A\u7F16\u8BD1\u4F7F\u7528\u5BF9\u5E94\u7684\u6A21\u5757\u7CFB\u7EDF\u3002</p></p><h2>6. lib</h2><p><span class="parse">\u7F16\u8BD1\u8FC7\u7A0B\u4E2D\u9700\u8981\u5F15\u5165\u7684\u5E93\u6587\u4EF6\u7684\u5217\u8868\u3002</span> string[]\u7C7B\u578B\uFF0C\u53EF\u9009\u7684\u503C\u6709\u5F88\u591A\uFF0C\u5E38\u7528\u7684\u6709ES5\uFF0CES6\uFF0CESNext\uFF0CDOM\uFF0CDOM.Iterable\u3001WebWorker\u3001ScriptHost\u7B49\u3002\u8BE5\u503C\u9ED8\u8BA4\u503C\u662F\u6839\u636E--target\u9009\u9879\u4E0D\u540C\u800C\u4E0D\u540C\u3002 \u5F53target\u4E3AES5\u65F6\uFF0C\u9ED8\u8BA4\u503C\u4E3A[&#39;DOM &#39;, &#39;ES5&#39;, &#39;ScriptHost&#39;];\u5F53target\u4E3AES6\u65F6\uFF0C\u9ED8\u8BA4\u503C\u4E3A[&#39;DOM&#39;, &#39;ES6&#39;, &#39;DOM.Iterable&#39;, &#39;ScriptHost&#39;] <br><p> \u4E3A\u4E86\u5728ts\u4EE3\u7801\u4E2D\u4F7F\u7528ES6\u4E2D\u7684\u7C7B\uFF0C\u6BD4\u5982Array.form\u3001Set\u3001Reflect\u7B49\uFF0C\u9700\u8981\u8BBE\u7F6Elib\u9009\u9879\uFF0C\u5728\u7F16\u8BD1\u8FC7\u7A0B\u4E2D\u628A\u8FD9\u4E9B\u6807\u51C6\u5E93\u5F15\u5165\u3002\u8FD9\u6837\u5728\u7F16\u8BD1\u8FC7\u7A0B\u4E2D\uFF0C\u5982\u679C\u9047\u5230\u5C5E\u4E8E\u8FD9\u4E9B\u6807\u51C6\u5E93\u7684class\u6216api\u65F6\uFF0Cts\u7F16\u8BD1\u5668\u4E0D\u4F1A\u62A5\u9519\u3002</p></p><h2>7. moduleResolution</h2><p><span class="parse">\u51B3\u5B9A\u5982\u4F55\u5904\u7406\u6A21\u5757\u3002</span> string\u7C7B\u578B\uFF0C\u201Cnode\u201D\u6216\u8005\u201Cclassic\u201D\uFF0C\u9ED8\u8BA4\u503C\uFF1A\u201Cclassic\u201D\u3002 <br><p> \u8BF4\u76F4\u767D\u70B9\uFF0C\u4E5F\u5C31\u662F\u9047\u5230import { AAA } from &#39;./aaa&#39;\u8BE5\u5982\u4F55\u53BB\u627E\u5BF9\u5E94\u6587\u4EF6\u6A21\u5757\u89E3\u6790\u3002\u5BF9\u4E8E\u5DE5\u7A0B\u9879\u76EE\uFF0C\u5EFA\u8BAE\u5927\u5BB6\u4F7F\u7528node\uFF08vue-cli3 ts\u6A21\u677F\u9ED8\u8BA4\u8BBE\u7F6E\u4E3Anode\u7B56\u7565\uFF09\uFF0C\u56E0\u4E3A\u8FD9\u4E2A\u66F4\u7B26\u5408\u5E73\u65F6\u6211\u4EEC\u7684\u4E66\u5199\u4E60\u60EF\u4EE5\u53CA\u8BA4\u77E5\uFF08\u5E73\u65F6\u90FD\u662Fwebpack\u6253\u5305\uFF0Cwebpack\u53C8\u57FA\u4E8Enode\u4E4B\u4E0A\uFF09\u3002</p></p>',9),C={class:"line-numbers"},w=s("        "),I={class:"language-javascript"},A=s(`\r
          // \u5728\u6E90\u6587\u4EF6/root/src/A.ts\u4E2Dimport { b } from "./moduleB"\r
          // \u4E24\u79CD\u89E3\u6790\u65B9\u5F0F\u67E5\u627E\u6587\u4EF6\u65B9\u5F0F\u4E0D\u540C\r
\r
          // classic\u6A21\u5757\u89E3\u6790\u65B9\u5F0F\r
          1. /root/src/moduleB.ts\r
          2. /root/src/moduleB.d.ts\r
\r
          // node\u6A21\u5757\u89E3\u6790\u65B9\u5F0F\r
          1. /root/src/moduleB.ts\r
          2. /root/src/moduleB.tsx\r
          3. /root/src/moduleB.d.ts\r
          4. /root/src/moduleB/package.json (if it specifies a "types" property)\r
          5. /root/src/moduleB/index.ts\r
          6. /root/src/moduleB/index.tsx\r
          7. /root/src/moduleB/index.d.ts\r
        `),B=[A],J=t("h2",null,"9. strictNullChecks",-1),O=t("p",null,[t("span",{class:"parse"},"\u662F\u5426\u542F\u7528\u4E25\u683C\u7684 null\u68C0\u67E5\u6A21\u5F0F\u3002"),s(" boolean\u503C\uFF0C\u9ED8\u8BA4\u503C\uFF1Afalse "),t("br"),t("p",null," \u672A\u5904\u7406\u7684null\u548Cundefined\u7ECF\u5E38\u4F1A\u5BFC\u81F4BUG\u7684\u4EA7\u751F\uFF0C\u6240\u4EE5TypeScript\u5305\u542B\u4E86strictNullChecks\u9009\u9879\u6765\u5E2E\u52A9\u6211\u4EEC\u51CF\u5C11\u5BF9\u8FD9\u79CD\u60C5\u51B5\u7684\u62C5\u5FE7\u3002 \u5F53\u542F\u7528\u4E86strictNullChecks\uFF0Cnull\u548Cundefined\u83B7\u5F97\u4E86\u5B83\u4EEC\u81EA\u5DF1\u5404\u81EA\u7684\u7C7B\u578Bnull\u548Cundefined\u3002\u5F00\u542F\u8BE5\u6A21\u5F0F\u6709\u52A9\u4E8E\u53D1\u73B0\u5E76\u5904\u7406\u53EF\u80FD\u4E3Aundefined\u7684\u8D4B\u503C\u3002 \u5982\u679C\u662F\u6B63\u5F0F\u9879\u76EE\uFF0C\u6211\u5EFA\u8BAE\u5F00\u542F\u8BE5\u9009\u9879;\u5982\u679C\u53EA\u662F\u7EC3\u624BTypeScirpt\uFF0C\u53EF\u4EE5\u5173\u95ED\u8BE5\u9009\u9879\uFF0C\u4E0D\u7136\u6240\u6709\u53EF\u80FD\u4E3Anull/undefined\u7684\u8D4B\u503C\uFF0C\u90FD\u9700\u8981\u5199\u8054\u5408\u7C7B\u578B\u3002")],-1),R={class:"line-numbers"},U=s("        "),P={class:"language-javascript"},F=s(`\r
        // \u672A\u5F00\u542FstrictNullChecks\uFF0Cnumber\u7C7B\u578B\u5305\u542B\u4E86null\u548Cundefined\u7C7B\u578B\r
        let foo: number = 123;\r
        foo = null; // Okay\r
        foo = undefined; // Okay\r
\r
        // \u5F00\u542FstrictNullChecks\r
        let foo: string[] | undefined = arr.find(key => key === 'test')\r
        // foo.push('1') // error - 'foo' is possibly 'undefined'\r
        foo && foo.push('1') // okay  \r
        `),V=[F],z=a('<span class="cite">\u6CE8\u610F\uFF1A\u542F\u7528 --strict\u76F8\u5F53\u4E8E\u542F\u7528 --noImplicitAny, --noImplicitThis, --alwaysStrict, --strictNullChecks, --strictFunctionTypes\u548C--strictPropertyInitialization</span><h2>10. noUnusedLocals</h2><p><span class="parse">\u6709\u672A\u4F7F\u7528\u7684\u53D8\u91CF\u65F6\uFF0C\u662F\u5426\u629B\u51FA\u9519\u8BEF\u3002</span> boolean\u503C\uFF0C\u9ED8\u8BA4\u503C\uFF1Afalse <br><p> \u987E\u540D\u601D\u4E49\uFF0C\u5F53\u53D1\u73B0\u53D8\u91CF\u5B9A\u4E49\u4F46\u6CA1\u6709\u4F7F\u7528\u65F6\uFF0C\u7F16\u8BD1\u4E0D\u62A5\u9519\u3002eslint\u7684rule\u4E2D\u4E5F\u6709\u8BE5\u6761\uFF0C\u5EFA\u8BAE\u6B63\u5F0F\u9879\u76EE\u5C06\u8BE5\u9009\u9879\u5F00\u542F\uFF0C\u8BBE\u7F6E\u4E3Atrue\uFF0C\u4F7F\u5F97\u4EE3\u7801\u5E72\u51C0\u6574\u6D01\u3002</p></p><h2>11. noUnusedParameters</h2><p><span class="parse">\u6709\u672A\u4F7F\u7528\u7684\u53C2\u6570\u65F6\uFF0C\u662F\u5426\u629B\u51FA\u9519\u8BEF</span> boolean\u503C\uFF0C\u9ED8\u8BA4\u503C\uFF1Afalse <br><p>\u5EFA\u8BAE\u6B63\u5F0F\u9879\u76EE\u5F00\u542F\u8BE5\u9009\u9879\uFF0C\u8BBE\u7F6E\u4E3Atrue\uFF0C\u7406\u7531\u540C\u4E0A\u3002</p></p><h2>12. allowJs</h2><p><span class="parse">\u662F\u5426\u5141\u8BB8\u7F16\u8BD1javascript\u6587\u4EF6</span> boolean\u503C\uFF0C\u9ED8\u8BA4\u503C\uFF1Afalse <br><p>\u5982\u679C\u8BBE\u7F6E\u4E3Atrue\uFF0Cjs\u540E\u7F00\u7684\u6587\u4EF6\u4E5F\u4F1A\u88ABtypescript\u8FDB\u884C\u7F16\u8BD1\u3002</p></p><h2>13. typeRoots\u548Ctypes</h2><p><span class="parse">\u9ED8\u8BA4\u6240\u6709\u53EF\u89C1\u7684&quot;@types&quot;\u5305\u4F1A\u5728\u7F16\u8BD1\u8FC7\u7A0B\u4E2D\u88AB\u5305\u542B\u8FDB\u6765\u3002</span><br><p>\u5982\u679C\u6307\u5B9A\u4E86typeRoots\uFF0C\u53EA\u6709typeRoots\u4E0B\u9762\u7684\u5305\u624D\u4F1A\u88AB\u5305\u542B\u8FDB\u6765\u3002\u5982\u679C\u6307\u5B9A\u4E86types\uFF0C\u53EA\u6709\u88AB\u5217\u51FA\u6765\u7684npm\u5305\u624D\u4F1A\u88AB\u5305\u542B\u8FDB\u6765\u3002\u8BE6\u7EC6\u5185\u5BB9\u53EF\u770B\u6B64\u5904</p></p><span class="cite">\u53EF\u4EE5\u6307\u5B9A&quot;types&quot;: []\u6765\u7981\u7528\u81EA\u52A8\u5F15\u5165@types\u5305</span><h2>14. files\u3001include\u548Cexclude</h2><p><span class="parse">\u7F16\u8BD1\u6587\u4EF6\u5305\u542B\u54EA\u4E9B\u6587\u4EF6\u4EE5\u53CA\u6392\u9664\u54EA\u4E9B\u6587\u4EF6\u3002</span><br><p>\u672A\u8BBE\u7F6Einclude\u65F6\uFF0C\u7F16\u8BD1\u5668\u9ED8\u8BA4\u5305\u542B\u5F53\u524D\u76EE\u5F55\u548C\u5B50\u76EE\u5F55\u4E0B\u6240\u6709\u7684TypeScript\u6587\u4EF6\uFF08.ts, .d.ts \u548C .tsx\uFF09\u3002\u5982\u679CallowJs\u88AB\u8BBE\u7F6E\u6210true\uFF0CJS\u6587\u4EF6\uFF08.js\u548C.jsx\uFF09\u4E5F\u88AB\u5305\u542B\u8FDB\u6765\u3002exclude\u6392\u9664\u90A3\u4E9B\u4E0D\u9700\u8981\u7F16\u8BD1\u7684\u6587\u4EF6\u6216\u6587\u4EF6\u5939\u3002</p></p>',12),H={class:"line-numbers"},W=s("        "),L={class:"language-javascript"},G=s(`\r
        {\r
         "compilerOptions": {},\r
         "include": [\r
              "src/**/*"\r
          ],\r
         "exclude": [\r
              "node_modules",\r
              "**/*.spec.ts"\r
          ]\r
        }\r
        `),X=[G],K=t("h2",null,"tsconfig.josn\u5168\u89E3\u6790",-1),Q={class:"line-numbers"},Y=s("        "),Z={class:"language-javascript"},$=s(`\r
  {\r
    "compilerOptions": {\r
      /* \u57FA\u672C\u9009\u9879 */\r
      "target": "es5",                       /* \u6307\u5B9A ECMAScript \u76EE\u6807\u7248\u672C: 'ES3' (default), 'ES5', 'ES2015',\r
                                                'ES2016', 'ES2017', or 'ESNEXT'\uFF08"ESNext"\u8868\u793A\u6700\u65B0\u7684ES\u8BED\u6CD5\uFF0C\r
                                                \u5305\u62EC\u8FD8\u5904\u5728stage X\u9636\u6BB5\uFF09\r
                                              */ \r
      "module": "commonjs",                  // \u6307\u5B9A\u4F7F\u7528\u6A21\u5757: 'commonjs', 'amd', 'system', 'umd' or 'es2015'\r
      "lib": [],                             // \u6307\u5B9A\u8981\u5305\u542B\u5728\u7F16\u8BD1\u4E2D\u7684\u5E93\u6587\u4EF6\r
      "allowJs": true,                       // \u5141\u8BB8\u7F16\u8BD1 javascript \u6587\u4EF6\r
      "checkJs": true,                       // \u62A5\u544A javascript \u6587\u4EF6\u4E2D\u7684\u9519\u8BEF\r
      "jsx": "preserve",                     // \u6307\u5B9A jsx \u4EE3\u7801\u7684\u751F\u6210: 'preserve', 'react-native', or 'react'\r
      "declaration": true,                   // \u751F\u6210\u76F8\u5E94\u7684 '.d.ts' \u6587\u4EF6\r
      "sourceMap": true,                     // \u751F\u6210\u76F8\u5E94\u7684 '.map' \u6587\u4EF6\r
      "outFile": "./",                       // \u5C06\u8F93\u51FA\u6587\u4EF6\u5408\u5E76\u4E3A\u4E00\u4E2A\u6587\u4EF6\r
      "outDir": "./",                        // \u6307\u5B9A\u8F93\u51FA\u76EE\u5F55\r
      "rootDir": "./",                       // \u7528\u6765\u63A7\u5236\u8F93\u51FA\u76EE\u5F55\u7ED3\u6784 --outDir.\r
      "removeComments": true,                // \u5220\u9664\u7F16\u8BD1\u540E\u7684\u6240\u6709\u7684\u6CE8\u91CA\r
      "noEmit": true,                        // \u4E0D\u751F\u6210\u8F93\u51FA\u6587\u4EF6\r
      "importHelpers": true,                 // \u4ECE tslib \u5BFC\u5165\u8F85\u52A9\u5DE5\u5177\u51FD\u6570\r
      "isolatedModules": true,               // \u5C06\u6BCF\u4E2A\u6587\u4EF6\u505A\u4E3A\u5355\u72EC\u7684\u6A21\u5757 \uFF08\u4E0E 'ts.transpileModule' \u7C7B\u4F3C\uFF09.\r
\r
      /* \u4E25\u683C\u7684\u7C7B\u578B\u68C0\u67E5\u9009\u9879 */\r
      "strict": true,                        // \u542F\u7528\u6240\u6709\u4E25\u683C\u7C7B\u578B\u68C0\u67E5\u9009\u9879\r
      "noImplicitAny": true,                 // \u5728\u8868\u8FBE\u5F0F\u548C\u58F0\u660E\u4E0A\u6709\u9690\u542B\u7684 any\u7C7B\u578B\u65F6\u62A5\u9519\r
      "strictNullChecks": true,              // \u542F\u7528\u4E25\u683C\u7684 null \u68C0\u67E5\r
      "noImplicitThis": true,                // \u5F53 this \u8868\u8FBE\u5F0F\u503C\u4E3A any \u7C7B\u578B\u7684\u65F6\u5019\uFF0C\u751F\u6210\u4E00\u4E2A\u9519\u8BEF\r
      "alwaysStrict": true,                  // \u4EE5\u4E25\u683C\u6A21\u5F0F\u68C0\u67E5\u6BCF\u4E2A\u6A21\u5757\uFF0C\u5E76\u5728\u6BCF\u4E2A\u6587\u4EF6\u91CC\u52A0\u5165 'use strict'\r
\r
      /* \u989D\u5916\u7684\u68C0\u67E5 */\r
      "noUnusedLocals": true,                // \u6709\u672A\u4F7F\u7528\u7684\u53D8\u91CF\u65F6\uFF0C\u629B\u51FA\u9519\u8BEF\r
      "noUnusedParameters": true,            // \u6709\u672A\u4F7F\u7528\u7684\u53C2\u6570\u65F6\uFF0C\u629B\u51FA\u9519\u8BEF\r
      "noImplicitReturns": true,             // \u5E76\u4E0D\u662F\u6240\u6709\u51FD\u6570\u91CC\u7684\u4EE3\u7801\u90FD\u6709\u8FD4\u56DE\u503C\u65F6\uFF0C\u629B\u51FA\u9519\u8BEF\r
      "noFallthroughCasesInSwitch": true,    // \u62A5\u544A switch \u8BED\u53E5\u7684 fallthrough \u9519\u8BEF\u3002\uFF08\u5373\uFF0C\u4E0D\u5141\u8BB8 switch \u7684 case \u8BED\u53E5\u8D2F\u7A7F\uFF09\r
\r
      /* \u6A21\u5757\u89E3\u6790\u9009\u9879 */\r
      "moduleResolution": "node",            /* \u9009\u62E9\u6A21\u5757\u89E3\u6790\u7B56\u7565\uFF1A 'node' (Node.js) or 'classic' (TypeScript pre-1.6)\u3002\r
                                                \u9ED8\u8BA4\u662Fclassic\r
                                             */ \r
      "baseUrl": "./",                       // \u7528\u4E8E\u89E3\u6790\u975E\u76F8\u5BF9\u6A21\u5757\u540D\u79F0\u7684\u57FA\u76EE\u5F55\r
      "paths": {},                           // \u6A21\u5757\u540D\u5230\u57FA\u4E8E baseUrl \u7684\u8DEF\u5F84\u6620\u5C04\u7684\u5217\u8868\r
      "rootDirs": [],                        // \u6839\u6587\u4EF6\u5939\u5217\u8868\uFF0C\u5176\u7EC4\u5408\u5185\u5BB9\u8868\u793A\u9879\u76EE\u8FD0\u884C\u65F6\u7684\u7ED3\u6784\u5185\u5BB9\r
      "typeRoots": [],                       // \u5305\u542B\u7C7B\u578B\u58F0\u660E\u7684\u6587\u4EF6\u5217\u8868\r
      "types": [],                           // \u9700\u8981\u5305\u542B\u7684\u7C7B\u578B\u58F0\u660E\u6587\u4EF6\u540D\u5217\u8868\r
      "allowSyntheticDefaultImports": true,  // \u5141\u8BB8\u4ECE\u6CA1\u6709\u8BBE\u7F6E\u9ED8\u8BA4\u5BFC\u51FA\u7684\u6A21\u5757\u4E2D\u9ED8\u8BA4\u5BFC\u5165\u3002\r
\r
      /* Source Map Options */\r
      "sourceRoot": "./",                    // \u6307\u5B9A\u8C03\u8BD5\u5668\u5E94\u8BE5\u627E\u5230 TypeScript \u6587\u4EF6\u800C\u4E0D\u662F\u6E90\u6587\u4EF6\u7684\u4F4D\u7F6E\r
      "mapRoot": "./",                       // \u6307\u5B9A\u8C03\u8BD5\u5668\u5E94\u8BE5\u627E\u5230\u6620\u5C04\u6587\u4EF6\u800C\u4E0D\u662F\u751F\u6210\u6587\u4EF6\u7684\u4F4D\u7F6E\r
      "inlineSourceMap": true,               // \u751F\u6210\u5355\u4E2A soucemaps \u6587\u4EF6\uFF0C\u800C\u4E0D\u662F\u5C06 sourcemaps \u751F\u6210\u4E0D\u540C\u7684\u6587\u4EF6\r
      "inlineSources": true,                 /* \u5C06\u4EE3\u7801\u4E0E sourcemaps \u751F\u6210\u5230\u4E00\u4E2A\u6587\u4EF6\u4E2D\uFF0C\u8981\u6C42\u540C\u65F6\u8BBE\u7F6E\u4E86 --inlineSourceMap \r
                                                \u6216 --sourceMap \u5C5E\u6027\r
                                              */\r
      /* \u5176\u4ED6\u9009\u9879 */\r
      "experimentalDecorators": true,        // \u542F\u7528\u88C5\u9970\u5668\r
      "emitDecoratorMetadata": true,         // \u4E3A\u88C5\u9970\u5668\u63D0\u4F9B\u5143\u6570\u636E\u7684\u652F\u6301\r
      "strictFunctionTypes": false           // \u7981\u7528\u51FD\u6570\u53C2\u6570\u53CC\u5411\u534F\u53D8\u68C0\u67E5\u3002\r
    },\r
    /* \u6307\u5B9A\u7F16\u8BD1\u6587\u4EF6\u6216\u6392\u9664\u6307\u5B9A\u7F16\u8BD1\u6587\u4EF6 */\r
    "include": [\r
        "src/**/*"\r
    ],\r
    "exclude": [\r
        "node_modules",\r
        "**/*.spec.ts"\r
    ],\r
    "files": [\r
      "core.ts",\r
      "sys.ts"\r
    ],\r
    // \u4ECE\u53E6\u4E00\u4E2A\u914D\u7F6E\u6587\u4EF6\u91CC\u7EE7\u627F\u914D\u7F6E\r
    "extends": "./config/base",\r
    // \u8BA9IDE\u5728\u4FDD\u5B58\u6587\u4EF6\u7684\u65F6\u5019\u6839\u636Etsconfig.json\u91CD\u65B0\u751F\u6210\u6587\u4EF6\r
    "compileOnSave": true // \u652F\u6301\u8FD9\u4E2A\u7279\u6027\u9700\u8981Visual Studio 2015\uFF0C TypeScript1.8.4\u4EE5\u4E0A\u5E76\u4E14\u5B89\u88C5atom-typescript\u63D2\u4EF6\r
  }\r
        \r
        `),tt=[$];function st(et,rt){const c=i,n=l("prism");return e(),r("div",null,[_,h,S,f,t("p",null,[y,E,u(c,{type:"primary",href:"https://www.typescriptlang.org/docs/handbook/decorators.html",target:"_blank"},{default:d(()=>[b]),_:1}),g,q,x]),v,t("pre",k,[j,o((e(),r("code",N,M)),[[n]])]),T,t("pre",C,[w,o((e(),r("code",I,B)),[[n]])]),J,O,t("pre",R,[U,o((e(),r("code",P,V)),[[n]])]),z,t("pre",H,[W,o((e(),r("code",L,X)),[[n]])]),K,t("pre",Q,[Y,o((e(),r("code",Z,tt)),[[n]])])])}var ft=p(m,[["render",st]]);export{ft as default};
